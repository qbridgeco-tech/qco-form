# QBridge - Coffee Traceability Platform

Platform registrasi dan verifikasi mill kopi Indonesia dengan integrasi form processor ke buyer dashboard.

## Struktur Proyek

```
qbridge/
├── index.html              # Entry point / portal
├── processor.html          # Form input data processor
├── buyer-dashboard.html    # Dashboard buyer (render dinamis)
├── js/
│   └── data-bridge.js      # Data bridge (localStorage API)
└── README.md
```

## Cara Deploy ke GitHub Pages

### Langkah 1: Buat Repository Baru di GitHub

1. Login ke [github.com](https://github.com)
2. Klik tombol **+** → **New repository**
3. Isi nama repository: `qbridge-coffee` (atau nama lain)
4. Pilih **Public** (agar GitHub Pages bisa gratis)
5. Jangan centang "Add a README file" (sudah ada)
6. Klik **Create repository**

### Langkah 2: Push Kode ke GitHub

Setelah membuat repository, GitHub akan menunjukkan perintah push. Jalankan di terminal:

```bash
# Ganti URL di bawah dengan URL repository Anda
# Contoh: https://github.com/USERNAME/qbridge-coffee.git
git remote add origin https://github.com/USERNAME/qbridge-coffee.git
git branch -M main
git push -u origin main
```

### Langkah 3: Aktifkan GitHub Pages

1. Di halaman repository GitHub, klik tab **Settings**
2. Di menu kiri, klik **Pages**
3. Di bagian "Build and deployment":
   - **Source**: Pilih **Deploy from a branch**
   - **Branch**: Pilih **main**, folder **/(root)**
4. Klik **Save**
5. Tunggu 1-2 menit

### Langkah 4: Akses Website

Setelah aktif, website akan tersedia di:
```
https://USERNAME.github.io/qbridge-coffee/
```

---

## Cara Testing

### Test 1: Data Flow Processor → Dashboard

1. Buka halaman **Processor Form** (`/processor.html`)
2. Isi form dengan data berikut (minimal):
   - Nama Processor: `Test Mill`
   - Alamat Lengkap: `Jl. Kopi No. 1, Desa Gayo, Aceh, 1200-2500 masl`
   - Kontak: `08123456789`
   - Jumlah Petani: `50`
   - Total Area: `100 ha`
   - Varietas: `Typica, Bourbon`
   - Harga Cherry: `20000`
   - SCA Score: `87.5`
3. Klik tombol **"💾 Simpan Form Processor"**
4. Setelah muncul pesan sukses, klik link **"→ Lihat di Buyer Dashboard"**
5. Pastikan mill baru muncul sebagai card dengan data yang sesuai

### Test 2: Detail Panel Dinamis

1. Di Buyer Dashboard, klik card mill manapun
2. Pastikan detail panel muncul dengan tab:
   - Overview (mill identity, facility, farm profile, certifications)
   - Quality & Trace (cupping scores, physical quality, traceability)
   - Farmer Welfare (5 komponen: price transparency, payment timeliness, quality incentive, contract compliance, satisfaction)
   - Export Readiness (Phytosanitary, ICO CO, PEB)
   - Buyer Tools (FSVP, Prior Notice, Landed Cost Calculator, Trade Finance, Sample Timeline)
   - Origin Story (auto-generated narrative)
3. Klik setiap tab dan verifikasi data sesuai

### Test 3: Sorting

1. Pilih **"Sort: Highest Cupping Score"** dari dropdown
2. Pastikan mills terurut dari SCA score tertinggi
3. Pilih **"Sort: Highest Welfare Score"**
4. Pastikan mills terurut dari welfare score tertinggi
5. Pilih **"Sort: QBridge Verified First"**
6. Pastikan mills dengan status "verified" muncul paling atas

### Test 4: localStorage Persistence

1. Tambahkan mill baru via Processor Form
2. Refresh halaman Buyer Dashboard (F5)
3. Mill baru harus tetap muncul (data disimpan di localStorage)
4. Buka Developer Tools → Application → Local Storage
5. Cari key `qbridge_mills_data` — isinya adalah array JSON semua mill

---

## Fitur

### Processor Form (`processor.html`)
- 11+ section form input lengkap
- Accordion section (expand/collapse)
- Conditional fields (muncul berdasarkan pilihan)
- Dynamic table rows (SDM, cupping history, production history)
- Multi-kebun profile (cloneable instances)
- SOP workflow editor
- Export document tracking (Phytosanitary, ICO, PEB, FDA)
- Farmer welfare data input
- Trade finance preferences
- Origin story & GI management
- **Save to localStorage** → otomatis muncul di Buyer Dashboard

### Buyer Dashboard (`buyer-dashboard.html`)
- **Dynamic mill cards** — render dari localStorage, bukan hardcoded
- Filter sidebar (UI demo — belum fully functional)
- Sort dropdown (Verified First, Highest SCA, Highest Welfare)
- Detail panel dengan 6 tab dinamis
- Export Readiness grid (Phytosanitary, ICO, PEB)
- Buyer Tools (FSVP, Prior Notice, Landed Cost Calculator)
- Trade Finance & Sample Timeline
- Origin Story auto-generated

### Data Bridge (`js/data-bridge.js`)
- 3 mill demo data (Gayo, Toraja, Flores)
- CRUD API: `getAllMills()`, `addMill()`, `getMillById()`, `updateMill()`, `deleteMill()`
- localStorage persistence
- Welfare score auto-calculation
- Status determination (verified/physical/core)

---

## Integrasi Backend (Untuk Production)

Saat ini menggunakan **localStorage** (data hanya di browser lokal). Untuk production, ganti `js/data-bridge.js` dengan koneksi ke backend API:

```javascript
// Contoh integrasi backend (ganti fungsi di data-bridge.js)
async function getAllMills() {
  const res = await fetch('/api/mills');
  return res.json();
}

async function addMill(millData) {
  const res = await fetch('/api/mills', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(millData)
  });
  return res.ok;
}
```

---

## Tech Stack

- **Frontend**: Pure HTML, CSS, JavaScript (vanilla)
- **Storage**: localStorage (browser)
- **Hosting**: Static (GitHub Pages / Netlify / Vercel compatible)
- **No build step required** — upload langsung

---

## License

MIT
