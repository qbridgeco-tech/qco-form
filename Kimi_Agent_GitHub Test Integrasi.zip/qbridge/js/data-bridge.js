/**
 * QBridge Data Bridge
 * Menghubungkan data dari Processor.html ke Buyer Dashboard
 * Menggunakan localStorage sebagai penyimpanan sementara
 */

// Key untuk localStorage
const STORAGE_KEY = 'qbridge_mills_data';

// Mill template/default data (untuk demo jika belum ada data)
const DEFAULT_MILLS = [
  {
    id: 'gayomill',
    millName: 'Gayo Mill',
    region: 'Aceh',
    status: 'verified',
    statusLabel: 'QBridge Verified + GI Authenticated',
    coffeeType: 'Arabica',
    processTypes: ['Washed', 'Natural'],
    elevation: '1,200–3,500 masl',
    farmerPartners: 150,
    annualCapacity: 45,
    giStatus: 'Gayo Highlands GI',
    scaScore: '86.5',
    welfareScore: 88,
    phytoStatus: 'VALID',
    icoStatus: 'VERIFIED',
    pebStatus: 'ACTIVE',
    overview: {
      legalEntity: 'PT Gayo Highlands Coffee',
      nib: '8120001234567',
      npwp: '09.123.456.7-123.000',
      established: '2015',
      contactPerson: 'Ahmad Fauzi (English) — +62 812 3456 7890',
      facilityType: 'Wet Mill + Dry Mill',
      capacity: '2,000 kg cherry/day',
      dryingBeds: '24 raised African beds',
      equipment: 'Pulping machine, fermentation tanks (12x), huller, color sorter',
      warehouse: 'Temperature-controlled green bean storage',
      totalFarmers: 150,
      totalArea: '320 hectares',
      varieties: 'Typica, Bourbon, Catimor, Ateng Super',
      harvest: 'October–March (main), May–July (fly crop)',
      certifications: [
        { name: 'Organic', detail: 'USDA Organic (cert# ORG-2024-IDN-045)' },
        { name: 'Fair Trade', detail: 'Fair Trade USA (cert# FT-2023-1122)' },
        { name: 'GI', detail: 'Gayo Highlands — Blockchain authenticated' },
        { name: 'QBridge', detail: 'Physical Visit — May 2026' }
      ]
    },
    quality: {
      cupping2026: '86.5 (Washed), 85.2 (Natural)',
      cupping2025: '85.8 (Washed), 84.9 (Natural)',
      cupping2024: '84.2 (Washed), 83.7 (Natural)',
      trend: 'Improving (+2.3 pts in 3 years)',
      moisture: '10.8–11.2%',
      screenSize: '17/18 (85%), 15/16 (15%)',
      defects: '2 primary, 5 secondary (Grade 1)',
      density: '720 g/L',
      waterActivity: '0.52 aw',
      lotCode: 'GB-2026-045-A',
      traceability: 'Farm → Collection Point → Wet Mill → Dry Mill → Export',
      blockchain: 'Verified on QBridge Chain',
      prediction: '86.2 ± 1.1',
      cga: '8.4%',
      caffeine: '1.32%',
      r2: '0.99'
    },
    welfare: {
      totalScore: 88,
      priceTransparency: { score: '22/25', publishedPrice: 'Rp 18,500/kg cherry', actualPrice: 'Rp 18,500/kg', advanceDays: 30, equalPrice: true },
      paymentTimeliness: { score: '24/25', avgDays: 9, bankVerified: true, paidWithin14Days: true },
      qualityIncentive: { score: '18/20', premium: 'Rp 2,000/kg', documented: true, training: 'Quarterly' },
      contractCompliance: { score: '14/15', contractRate: '94.7%', templateReviewed: true },
      satisfaction: { score: '10/15', sampleSize: 10, avgRating: '7.8/10', feedback: 'Request better road access to collection point' }
    },
    export: {
      phyto: { status: 'VALID', number: 'IDN-PHY-2026-045', port: 'Tanjung Priok, Jakarta', inspectionDate: 'May 15, 2026', expiry: 'Dec 2026', declaration: 'Free from Coffee Berry Borer (Hypothenemus hampei)' },
      ico: { status: 'VERIFIED', number: 'CO-IDN-2026-1122', issueDate: 'April 2026', database: 'MATCHED' },
      peb: { status: 'ACTIVE', number: 'PEB-2026-8847', validity: 'Jan–Dec 2026', customs: 'PASSED', lastShipment: 'May 2026' }
    },
    buyerTools: {
      fsvp: {
        hazardAnalysis: 'Completed by QBridge field team',
        supplierVerification: 'On-site audit records (Physical Visit)',
        correctiveActions: 'None in 24 months',
        reevaluation: 'December 2026',
        fdaReg: 'FDA-REG-2026-8847'
      },
      priorNotice: {
        manufacturer: 'Gayo Mill, Aceh, Indonesia',
        grower: '150 farmer partners (aggregated data)',
        lotCode: 'GB-2026-045-A',
        fdaReg: 'FDA-REG-2026-8847',
        quantity: '19,200 kg | FCL Container',
        htsCode: '0901.11.00 (Green Coffee, Not Roasted)'
      },
      landedCost: {
        fob: 4.50,
        oceanFreight: 0.18,
        insurance: 0.05,
        customsDuty: 0.00,
        mpf: 0.016,
        hmf: 0.006,
        brokerage: 0.08
      },
      tradeFinance: {
        escrow: 'Funds held until inspection at US port',
        installment: '30% deposit | 40% at ship | 30% at arrival',
        lc: 'LC at sight via partner bank (Mandiri/BCA correspondent)',
        currencyHedge: 'IDR/USD forward rate lock (90 days)',
        paymentProtection: 'QBridge guarantees farmer payment SOP compliance'
      },
      sampleTimeline: [
        { label: 'Sample Roasted', date: 'May 10', status: 'done' },
        { label: 'Shipped DHL', date: 'May 12', status: 'done' },
        { label: 'In Transit', date: 'May 15', status: 'transit' },
        { label: 'Delivered', date: 'May 18 (est.)', status: 'pending' },
        { label: 'Cupping Feedback', date: '—', status: 'pending' }
      ]
    },
    originStory: {
      title: 'Gayo Highlands: Where the Earth Meets the Sky',
      narrative: `Nestled between 1,200 and 3,500 meters above sea level in the Gayo Highlands of Aceh, <strong>150 smallholder farmers</strong> cultivate some of Indonesia's most sought-after Arabica coffee. This lot — <strong>GB-2026-045-A</strong> — represents the culmination of meticulous post-harvest handling at Gayo Mill, a <strong>QBridge Physical Verified</strong> facility with documented SOPs for washed and natural processing.<br><br>Every cherry in this lot was purchased at a <strong>transparent, published price of Rp 18,500/kg</strong>, with payment completed within <strong>9 days</strong> of delivery — verified by bank records and earning this mill a <strong>Farmer Welfare Score of 88/100</strong>. Farmers who deliver Grade A cherry receive an additional <strong>Rp 2,000/kg quality premium</strong>, creating a direct incentive for excellence at the farm gate.<br><br>The <strong>Gayo Highlands Geographical Indication</strong> is blockchain-authenticated on QBridge, guaranteeing that every bean in this lot originates from the designated GI polygon. With a <strong>predicted SCA cupping score of 86.2</strong> (NIR spectroscopy, R² = 0.99), this coffee offers the bright acidity, full body, and herbal complexity that has made Gayo a cornerstone of Indonesia's specialty coffee reputation.`,
      photos: []
    }
  },
  {
    id: 'torajamill',
    millName: 'Toraja Mill',
    region: 'Sulawesi Selatan',
    status: 'core',
    statusLabel: 'Core Checked',
    coffeeType: 'Arabica',
    processTypes: ['Washed', 'Natural'],
    elevation: '1,200–3,500 masl',
    farmerPartners: 80,
    annualCapacity: 30,
    giStatus: '',
    scaScore: '84.2',
    welfareScore: 72,
    phytoStatus: 'VALID',
    icoStatus: 'VERIFIED',
    pebStatus: 'PENDING',
    overview: {
      legalEntity: 'CV Toraja Coffee Processors',
      nib: '8120007654321',
      npwp: '09.765.432.1-123.000',
      established: '2018',
      contactPerson: 'Rina Sapan — +62 823 4567 8901',
      facilityType: 'Wet Mill + Dry Mill',
      capacity: '1,500 kg cherry/day',
      dryingBeds: '16 raised African beds',
      equipment: 'Pulping machine, fermentation tanks (8x), huller',
      warehouse: 'Green bean storage with natural ventilation',
      totalFarmers: 80,
      totalArea: '180 hectares',
      varieties: 'S795, Typica',
      harvest: 'March–September (main), November–January (fly crop)',
      certifications: [
        { name: 'QBridge', detail: 'Core Check — March 2026' }
      ]
    },
    quality: {
      cupping2026: '84.2 (Washed), 83.5 (Natural)',
      cupping2025: '83.0 (Washed), 82.5 (Natural)',
      cupping2024: '82.0 (Washed), 81.5 (Natural)',
      trend: 'Improving (+2.2 pts in 3 years)',
      moisture: '11.0–11.5%',
      screenSize: '16/17 (80%), 15/16 (20%)',
      defects: '3 primary, 6 secondary (Grade 1)',
      density: '710 g/L',
      waterActivity: '0.55 aw',
      lotCode: 'TR-2026-078-B',
      traceability: 'Farm → Collection Point → Wet Mill → Dry Mill → Export',
      blockchain: 'Verified on QBridge Chain',
      prediction: '84.0 ± 1.2',
      cga: '7.8%',
      caffeine: '1.28%',
      r2: '0.98'
    },
    welfare: {
      totalScore: 72,
      priceTransparency: { score: '18/25', publishedPrice: 'Rp 16,000/kg cherry', actualPrice: 'Rp 16,000/kg', advanceDays: 14, equalPrice: true },
      paymentTimeliness: { score: '20/25', avgDays: 12, bankVerified: true, paidWithin14Days: true },
      qualityIncentive: { score: '15/20', premium: 'Rp 1,500/kg', documented: true, training: 'Bi-annually' },
      contractCompliance: { score: '10/15', contractRate: '75%', templateReviewed: false },
      satisfaction: { score: '9/15', sampleSize: 8, avgRating: '7.2/10', feedback: 'Request advance payment for harvest season' }
    },
    export: {
      phyto: { status: 'VALID', number: 'IDN-PHY-2026-078', port: 'Makassar', inspectionDate: 'March 20, 2026', expiry: 'Sep 2026', declaration: 'Free from Coffee Berry Borer (Hypothenemus hampei)' },
      ico: { status: 'VERIFIED', number: 'CO-IDN-2026-0789', issueDate: 'February 2026', database: 'MATCHED' },
      peb: { status: 'PENDING', number: 'PEB-2026-4521', validity: 'Pending', customs: 'PENDING', lastShipment: 'N/A' }
    },
    buyerTools: {
      fsvp: {
        hazardAnalysis: 'Completed by QBridge field team',
        supplierVerification: 'On-site audit records (Core Check)',
        correctiveActions: 'None in 24 months',
        reevaluation: 'March 2027',
        fdaReg: 'FDA-REG-2026-4521'
      },
      priorNotice: {
        manufacturer: 'Toraja Mill, Sulawesi Selatan, Indonesia',
        grower: '80 farmer partners (aggregated data)',
        lotCode: 'TR-2026-078-B',
        fdaReg: 'FDA-REG-2026-4521',
        quantity: '12,800 kg | LCL Container',
        htsCode: '0901.11.00 (Green Coffee, Not Roasted)'
      },
      landedCost: {
        fob: 4.20,
        oceanFreight: 0.20,
        insurance: 0.05,
        customsDuty: 0.00,
        mpf: 0.015,
        hmf: 0.006,
        brokerage: 0.08
      },
      tradeFinance: {
        escrow: 'Funds held until inspection at US port',
        installment: '30% deposit | 40% at ship | 30% at arrival',
        lc: 'LC at sight via partner bank (Mandiri/BCA correspondent)',
        currencyHedge: 'IDR/USD forward rate lock (60 days)',
        paymentProtection: 'QBridge guarantees farmer payment SOP compliance'
      },
      sampleTimeline: [
        { label: 'Sample Roasted', date: 'Apr 20', status: 'done' },
        { label: 'Shipped DHL', date: 'Apr 22', status: 'done' },
        { label: 'In Transit', date: 'Apr 25', status: 'done' },
        { label: 'Delivered', date: 'Apr 28', status: 'done' },
        { label: 'Cupping Feedback', date: 'May 5', status: 'done' }
      ]
    },
    originStory: {
      title: 'Toraja: Coffee from the Land of the Heavenly Kings',
      narrative: `High in the mountainous region of South Sulawesi, <strong>80 dedicated farmer partners</strong> cultivate Toraja Arabica coffee at elevations between 1,200 and 3,500 meters above sea level. This lot — <strong>TR-2026-078-B</strong> — was processed at Toraja Mill with meticulous attention to both washed and natural processing protocols.<br><br>The farmers in this supply chain receive a <strong>transparent published price of Rp 16,000/kg cherry</strong>, with payment completed within <strong>12 days</strong> on average. The mill has a <strong>Farmer Welfare Score of 72/100</strong>, with ongoing improvements in contract coverage and quality premium systems.<br><br>With an <strong>SCA cupping score of 84.2</strong>, this Toraja coffee offers a smooth body with balanced acidity and earthy undertones characteristic of the region's volcanic soil.`,
      photos: []
    }
  },
  {
    id: 'floresmill',
    millName: 'Flores Mill',
    region: 'Nusa Tenggara Timur',
    status: 'physical',
    statusLabel: 'Physical Verified',
    coffeeType: 'Arabica',
    processTypes: ['Washed', 'Natural', 'Honey'],
    elevation: '1,500–2,800 masl',
    farmerPartners: 200,
    annualCapacity: 60,
    giStatus: '',
    scaScore: '88.0',
    welfareScore: 91,
    phytoStatus: 'VALID',
    icoStatus: 'VERIFIED',
    pebStatus: 'ACTIVE',
    overview: {
      legalEntity: 'Koperasi Flores Coffee Union',
      nib: '8120009876543',
      npwp: '09.987.654.3-321.000',
      established: '2012',
      contactPerson: 'Maria Ngka — +62 813 7890 1234',
      facilityType: 'Wet Mill + Dry Mill',
      capacity: '2,500 kg cherry/day',
      dryingBeds: '30 raised African beds',
      equipment: 'Penagos pulper, fermentation tanks (16x), huller, color sorter',
      warehouse: 'Climate-controlled warehouse with humidity monitoring',
      totalFarmers: 200,
      totalArea: '450 hectares',
      varieties: 'Bourbon, Typica, S795',
      harvest: 'May–October (main), December–February (fly crop)',
      certifications: [
        { name: 'Organic', detail: 'EU Organic (cert# ORG-2025-IDN-078)' },
        { name: 'Fair Trade', detail: 'Fair Trade International (cert# FT-2024-2201)' },
        { name: 'QBridge', detail: 'Physical Visit — April 2026' }
      ]
    },
    quality: {
      cupping2026: '88.0 (Washed), 87.2 (Natural), 86.8 (Honey)',
      cupping2025: '87.0 (Washed), 86.5 (Natural), 86.0 (Honey)',
      cupping2024: '85.5 (Washed), 85.0 (Natural), 84.5 (Honey)',
      trend: 'Improving (+2.5 pts in 3 years)',
      moisture: '10.5–11.0%',
      screenSize: '17/18 (90%), 16/17 (10%)',
      defects: '1 primary, 3 secondary (Grade 1)',
      density: '730 g/L',
      waterActivity: '0.50 aw',
      lotCode: 'FL-2026-112-C',
      traceability: 'Farm → Collection Point → Wet Mill → Dry Mill → Export',
      blockchain: 'Verified on QBridge Chain',
      prediction: '87.8 ± 0.9',
      cga: '8.8%',
      caffeine: '1.35%',
      r2: '0.99'
    },
    welfare: {
      totalScore: 91,
      priceTransparency: { score: '25/25', publishedPrice: 'Rp 20,000/kg cherry', actualPrice: 'Rp 20,000/kg', advanceDays: 45, equalPrice: true },
      paymentTimeliness: { score: '25/25', avgDays: 5, bankVerified: true, paidWithin14Days: true },
      qualityIncentive: { score: '20/20', premium: 'Rp 3,000/kg', documented: true, training: 'Monthly' },
      contractCompliance: { score: '14/15', contractRate: '96%', templateReviewed: true },
      satisfaction: { score: '7/15', sampleSize: 15, avgRating: '8.5/10', feedback: 'Request access to microfinance and crop insurance' }
    },
    export: {
      phyto: { status: 'VALID', number: 'IDN-PHY-2026-112', port: 'Surabaya', inspectionDate: 'April 10, 2026', expiry: 'Oct 2026', declaration: 'Free from Coffee Berry Borer (Hypothenemus hampei)' },
      ico: { status: 'VERIFIED', number: 'CO-IDN-2026-2233', issueDate: 'March 2026', database: 'MATCHED' },
      peb: { status: 'ACTIVE', number: 'PEB-2026-2215', validity: 'Jan–Dec 2026', customs: 'PASSED', lastShipment: 'April 2026' }
    },
    buyerTools: {
      fsvp: {
        hazardAnalysis: 'Completed by QBridge field team',
        supplierVerification: 'On-site audit records (Physical Visit)',
        correctiveActions: '1 minor in 24 months (resolved)',
        reevaluation: 'October 2026',
        fdaReg: 'FDA-REG-2026-2215'
      },
      priorNotice: {
        manufacturer: 'Flores Mill, NTT, Indonesia',
        grower: '200 farmer partners (aggregated data)',
        lotCode: 'FL-2026-112-C',
        fdaReg: 'FDA-REG-2026-2215',
        quantity: '24,000 kg | FCL Container',
        htsCode: '0901.11.00 (Green Coffee, Not Roasted)'
      },
      landedCost: {
        fob: 4.80,
        oceanFreight: 0.16,
        insurance: 0.05,
        customsDuty: 0.00,
        mpf: 0.017,
        hmf: 0.006,
        brokerage: 0.08
      },
      tradeFinance: {
        escrow: 'Funds held until inspection at US port',
        installment: '30% deposit | 40% at ship | 30% at arrival',
        lc: 'LC at sight via partner bank (Mandiri/BCA correspondent)',
        currencyHedge: 'IDR/USD forward rate lock (90 days)',
        paymentProtection: 'QBridge guarantees farmer payment SOP compliance'
      },
      sampleTimeline: [
        { label: 'Sample Roasted', date: 'May 1', status: 'done' },
        { label: 'Shipped DHL', date: 'May 3', status: 'done' },
        { label: 'In Transit', date: 'May 6', status: 'done' },
        { label: 'Delivered', date: 'May 9', status: 'done' },
        { label: 'Cupping Feedback', date: 'May 12', status: 'done' }
      ]
    },
    originStory: {
      title: 'Flores: Volcanic Elegance in Every Bean',
      narrative: `On the volcanic slopes of Flores Island in East Nusa Tenggara, <strong>200 smallholder farmers</strong> nurture Arabica coffee at elevations from 1,500 to 2,800 meters. This exceptional lot — <strong>FL-2026-112-C</strong> — was processed at Flores Mill, a <strong>QBridge Physical Verified</strong> facility renowned for its meticulous handling of washed, natural, and honey processing methods.<br><br>The cooperative model ensures every farmer receives a <strong>published price of Rp 20,000/kg cherry</strong> — paid within just <strong>5 days</strong> on average — earning this supply chain a remarkable <strong>Farmer Welfare Score of 91/100</strong>. Grade A cherry commands an additional <strong>Rp 3,000/kg premium</strong>, with monthly quality training sessions keeping farmers engaged and invested in excellence.<br><br>With a <strong>predicted SCA cupping score of 87.8</strong> (NIR spectroscopy, R² = 0.99), this Flores coffee delivers a complex cup with floral notes, bright citrus acidity, and a silky body that reflects the island's unique volcanic terroir.`,
      photos: []
    }
  }
];

// Fungsi untuk mendapatkan semua data mill dari localStorage
function getAllMills() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      // Inisialisasi dengan default data
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_MILLS));
      return DEFAULT_MILLS;
    }
    return JSON.parse(stored);
  } catch (e) {
    console.error('Error reading mills data:', e);
    return DEFAULT_MILLS;
  }
}

// Fungsi untuk menyimpan semua data mill
function saveAllMills(mills) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(mills));
    return true;
  } catch (e) {
    console.error('Error saving mills data:', e);
    return false;
  }
}

// Fungsi untuk menambah mill baru (dari form processor)
function addMill(millData) {
  const mills = getAllMills();
  millData.id = millData.id || 'mill_' + Date.now();
  mills.push(millData);
  return saveAllMills(mills);
}

// Fungsi untuk mendapatkan mill berdasarkan ID
function getMillById(millId) {
  const mills = getAllMills();
  return mills.find(m => m.id === millId) || null;
}

// Fungsi untuk update mill
function updateMill(millId, updatedData) {
  const mills = getAllMills();
  const idx = mills.findIndex(m => m.id === millId);
  if (idx >= 0) {
    mills[idx] = { ...mills[idx], ...updatedData };
    return saveAllMills(mills);
  }
  return false;
}

// Fungsi untuk menghapus mill
function deleteMill(millId) {
  const mills = getAllMills();
  const filtered = mills.filter(m => m.id !== millId);
  return saveAllMills(filtered);
}

// Reset ke default (untuk testing)
function resetToDefault() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_MILLS));
  return DEFAULT_MILLS;
}

// Export functions untuk global access
window.QBridgeData = {
  getAllMills,
  saveAllMills,
  addMill,
  getMillById,
  updateMill,
  deleteMill,
  resetToDefault,
  STORAGE_KEY
};
